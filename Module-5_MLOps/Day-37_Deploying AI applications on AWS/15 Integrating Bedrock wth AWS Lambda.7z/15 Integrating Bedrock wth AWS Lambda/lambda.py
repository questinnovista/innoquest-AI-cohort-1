import json
import boto3

model_id="amazon.nova-lite-v1:0"
bedrock_runtime = boto3.client("bedrock-runtime", "us-east-1")

def lambda_handler(event, context):
    print(event)
    messages = [
    {
        "role": "user",
        "content": [{"text": "Write a short poem about spring."}]
    }
    ]

    body = json.dumps({
        "messages": messages

    })

    response = bedrock_runtime.invoke_model(
    modelId=model_id,
    body=body,
    contentType="application/json",
    accept="application/json"
    )

    resp_json = json.loads(response.get('body').read()).get('output').get('message').get('content')[0].get('text')

    return {
        'statusCode': 200,
        'body': json.dumps(resp_json)
    }
