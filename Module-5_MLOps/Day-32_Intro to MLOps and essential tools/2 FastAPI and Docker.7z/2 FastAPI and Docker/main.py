from fastapi import FastAPI
from pydantic import BaseModel, EmailStr, Field

class User(BaseModel):
    username: str = Field(min_length=3, max_length=50)
    email: EmailStr
    age: int

    class Config:
        min_anystr_length = 1
        anystr_strip_whitespace = True


app = FastAPI()


@app.get("/")
def read_root():
    return {"Hello": "World"}


@app.post("/users/")
async def create_user(user: User):
    # If validation passes, process the user data
    return {"message": "User created successfully", "user": user}

@app.get("/users/{user_id}")
async def read_user(user_id: int):
    # Simulate fetching user data from a database
    fake_user_db = {1: {"username": "johndoe", "email": "johndoe@example.com", "age": 30}}
    user = fake_user_db.get(user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return user
