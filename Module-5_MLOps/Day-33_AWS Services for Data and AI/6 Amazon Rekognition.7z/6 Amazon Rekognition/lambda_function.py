import json
import boto3
import os

rekognition_client = boto3.client('rekognition')
s3_client = boto3.client('s3')

def lambda_handler(event, context):
    # Extract bucket name and image key from the event
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    image_key = event['Records'][0]['s3']['object']['key']
    
    # Call Rekognition to detect labels in the image
    response = rekognition_client.detect_labels(
        Image={'S3Object': {'Bucket': bucket_name, 'Name': image_key}},
        MaxLabels=10,
        MinConfidence=75
    )
    
    # Prepare the labels data
    labels = [{'Name': label['Name'], 'Confidence': label['Confidence']} for label in response['Labels']]
    labels_data = {'Image': image_key, 'Labels': labels}
    
    # Define the output JSON file path
    output_key = 'processed/' + os.path.splitext(image_key)[0] + '_labels.json'
    
    # Upload the labels data to S3
    s3_client.put_object(
        Bucket=bucket_name,
        Key=output_key,
        Body=json.dumps(labels_data),
        ContentType='application/json'
    )
    
    return {
        'statusCode': 200,
        'body': json.dumps('Image processed successfully')
    }
