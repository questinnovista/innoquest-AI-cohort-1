import boto3
import pandas as pd
import os
import tempfile

s3 = boto3.client('s3')

# Define the columns to drop
COLUMNS_TO_DROP = ['First Name', 'Last name']  # Replace with actual column names

def lambda_handler(event, context):
    print("Event:", event)

    # Extract bucket and object key from event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    
    # Download the Excel file to temp location
    with tempfile.TemporaryDirectory() as tmpdir:
        download_path = os.path.join(tmpdir, os.path.basename(key))
        s3.download_file(bucket, key, download_path)

        # Read Excel using pandas
        df = pd.read_csv(download_path)
        
        # Drop unwanted columns
        df_cleaned = df.drop(columns=COLUMNS_TO_DROP, errors='ignore')
        
        # Save the cleaned Excel to temp location
        output_filename = os.path.basename(key)
        upload_key = f"processed/{output_filename}"
        upload_path = os.path.join(tmpdir, output_filename)
        df_cleaned.to_csv(upload_path, index=False)

        # Upload cleaned file back to S3
        s3.upload_file(upload_path, bucket, upload_key)
        print(f"File processed and uploaded to {upload_key}")

    return {
        'statusCode': 200,
        'body': f"File cleaned and uploaded to {upload_key}"
    }
